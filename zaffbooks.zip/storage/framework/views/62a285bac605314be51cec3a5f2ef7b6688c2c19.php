<h3><?php echo e($title); ?></h3>
<br>

<a href="<?php echo e(url('/').'/uploads/'.$link); ?>" style="
background-color: #4CAF50;
border: none;
color: white;
padding: 15px 32px;
text-align: center;
text-decoration: none;
display: inline-block;
font-size: 16px;
border-radius:5px">
 Download Now
</a>



<br><br>
<p style="font-size:12px"><?php echo e($dsiclaim); ?></p>
<?php /**PATH C:\xampp\htdocs\Main-projects\zenBooks\resources\views/email.blade.php ENDPATH**/ ?>