<h3>{{ $title }}</h3>
<br>

<a href="{{ url('/').'/uploads/'.$link }}" style="
background-color: #4CAF50;
border: none;
color: white;
padding: 15px 32px;
text-align: center;
text-decoration: none;
display: inline-block;
font-size: 16px;
border-radius:5px">
 Download Now
</a>



<br><br>
<p style="font-size:12px">{{ $dsiclaim }}</p>
